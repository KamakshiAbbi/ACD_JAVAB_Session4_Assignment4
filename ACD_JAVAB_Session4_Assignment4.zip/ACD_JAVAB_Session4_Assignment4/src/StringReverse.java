//Session4_Assignment3 : 8.5.2016
//Author: Kamakshi Abbi
import java.util.Scanner;
public class StringReverse {
	public static int calculateOccurance(String text){
		int count=0;
		for (int i = 0; i < text.length(); i++){
			if(text.charAt(i) == ' '){
				count++;
			}
		}
		return count;
	}
	public static void reverse(String text){
		StringBuffer strb = new StringBuffer();
		int len = calculateOccurance(text);
		String[] str = new String[len];
		str = text.split(" ");
		for (int i = str.length-1; i>=0; i--){
			strb.append(str[i]).append(" ");
		}
		System.out.println("Reverse of string is :");
		System.out.println(strb);
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String text;
		System.out.println("Enter the string :");
		text = input.nextLine();
		input.close();
		reverse(text);
	}

}
